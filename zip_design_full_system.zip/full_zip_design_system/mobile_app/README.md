# Mobile (Expo React Native)

## Kurulum & Çalıştırma (Emülatör kullanıyorsanız)

1. Node & Expo CLI kurun:
   ```bash
   npm install -g expo-cli
   ```
2. Proje dizinine girin:
   ```bash
   cd mobile_app
   npm install
   ```
3. Backend'i yerelde `http://localhost:5000` olarak çalıştırın.
   - Android emülatör (Android Studio) kullanıyorsanız mobile app içindeki API host `10.0.2.2` olarak ayarlanmıştır.
   - Gerçek cihaz kullanıyorsanız backend için bilgisayarınızın LAN IP'sini kullanın (örn: http://192.168.1.25:5000).
4. Expo başlatın:
   ```bash
   npm start
   ```
5. Emülatörde çalıştırın veya Expo Go ile test edin.

Varsayılan admin login test için backend seed ile `admin` / `admin123` kullanabilirsiniz (seed çalıştırın).
