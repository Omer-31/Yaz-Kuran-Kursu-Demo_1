import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, Button, TextInput, Alert } from 'react-native';
import axios from 'axios';

export default function Dashboard() {
  const [summary, setSummary] = useState({});
  const [students, setStudents] = useState([]);
  const API = 'http://10.0.2.2:5000';

  useEffect(()=>{ fetchSummary(); fetchStudents(); }, []);

  const fetchSummary = async () => {
    try {
      const token = global.apiToken;
      const res = await axios.get(API + '/api/admin/dashboard', { headers: { Authorization: 'Bearer ' + token }});
      setSummary(res.data);
    } catch (e) { console.error(e); }
  };

  const fetchStudents = async () => {
    try {
      const token = global.apiToken;
      const res = await axios.get(API + '/api/students', { headers:{ Authorization: 'Bearer ' + token }});
      setStudents(res.data);
    } catch (e) { console.error(e); }
  };

  return (
    <View style={{flex:1,padding:10}}>
      <Text style={{fontSize:18}}>Dashboard - Ödemeler</Text>
      <Text>Toplam öğrenci: {summary.totalStudents || 0}</Text>
      <Text>Toplam ödenen: {summary.paymentsSum || 0}</Text>

      <Text style={{marginTop:20,fontSize:16}}>Hızlı Ödeme Girişi</Text>
      <FlatList data={students} keyExtractor={i=>''+i.id} renderItem={({item})=>(
        <View style={{padding:8,borderBottomWidth:1}}>
          <Text>{item.first_name} {item.last_name}</Text>
          <PaymentRow student={item} />
        </View>
      )} />
    </View>
  );
}

function PaymentRow({ student }) {
  const [amount, setAmount] = React.useState('');
  const API = 'http://10.0.2.2:5000';
  const submit = async () => {
    try {
      const token = global.apiToken;
      await axios.post(API + '/api/payments', { student_id: student.id, amount: parseFloat(amount) }, { headers: { Authorization: 'Bearer ' + token }});
      Alert.alert('Başarılı', 'Ödeme kaydedildi');
    } catch (e) {
      Alert.alert('Hata', e.response?.data?.message || e.message);
    }
  };
  return (
    <View style={{flexDirection:'row',alignItems:'center', marginTop:8}}>
      <TextInput placeholder="TL" keyboardType="numeric" value={amount} onChangeText={setAmount} style={{borderWidth:1,padding:6,width:90,marginRight:8,borderRadius:6}} />
      <Button title="Kaydet" onPress={submit} />
    </View>
  );
}
