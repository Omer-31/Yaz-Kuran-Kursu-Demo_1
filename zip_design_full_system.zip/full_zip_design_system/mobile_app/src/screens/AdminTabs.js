import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Dashboard from './Dashboard';
import Students from './Students';
import Dorms from './Dorms';
import Reports from './Reports';

const Tab = createBottomTabNavigator();

export default function AdminTabs() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Dashboard" component={Dashboard} />
      <Tab.Screen name="Öğrenciler" component={Students} />
      <Tab.Screen name="Yurtlar" component={Dorms} />
      <Tab.Screen name="Raporlar" component={Reports} />
    </Tab.Navigator>
  )
}
