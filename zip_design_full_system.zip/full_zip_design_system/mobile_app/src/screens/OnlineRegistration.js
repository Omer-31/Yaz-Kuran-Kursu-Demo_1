import React, { useState } from 'react';
import { View, TextInput, Button, Alert, ScrollView } from 'react-native';
import axios from 'axios';

export default function OnlineRegistration({ navigation }) {
  const [first, setFirst] = useState('');
  const [last, setLast] = useState('');
  const [guardian1, setGuardian1] = useState('');
  const [guardian2, setGuardian2] = useState(''); // optional
  const API = 'http://10.0.2.2:5000';

  const submit = async () => {
    try {
      const payload = {
        student: { first_name: first, last_name: last },
        guardians: [
          { name: guardian1, is_primary: true },
          ...(guardian2 ? [{ name: guardian2, is_primary:false }] : [])
        ]
      };
      await axios.post(API + '/api/registrations', { form_data: payload });
      Alert.alert('Başarılı', 'Kayıt alındı');
      navigation.goBack();
    } catch (e) { Alert.alert('Hata', e.message); }
  };

  return (
    <ScrollView style={{padding:12}}>
      <TextInput placeholder="Öğrenci ad" value={first} onChangeText={setFirst} style={{borderWidth:1,padding:8,marginBottom:8}}/>
      <TextInput placeholder="Öğrenci soyad" value={last} onChangeText={setLast} style={{borderWidth:1,padding:8,marginBottom:8}}/>
      <TextInput placeholder="Veli 1 (zorunlu)" value={guardian1} onChangeText={setGuardian1} style={{borderWidth:1,padding:8,marginBottom:8}}/>
      <TextInput placeholder="Veli 2 (opsiyonel)" value={guardian2} onChangeText={setGuardian2} style={{borderWidth:1,padding:8,marginBottom:8}}/>
      <Button title="Kayıt Gönder" onPress={submit} />
    </ScrollView>
  );
}
