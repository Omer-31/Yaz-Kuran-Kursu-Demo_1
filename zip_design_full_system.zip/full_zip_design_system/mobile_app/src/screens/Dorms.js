import React, { useEffect, useState } from 'react';
import { View, FlatList, Text } from 'react-native';
import axios from 'axios';

export default function Dorms() {
  const [dorms, setDorms] = useState([]);
  const API = 'http://10.0.2.2:5000';

  useEffect(()=>{ fetchDorms(); }, []);

  const fetchDorms = async () => {
    try {
      const token = global.apiToken;
      const res = await axios.get(API + '/api/dorms', { headers:{ Authorization: 'Bearer ' + token }});
      setDorms(res.data);
    } catch (e) { console.error(e); }
  };

  return (
    <View style={{flex:1}}>
      <FlatList data={dorms} keyExtractor={i=>''+i.id} renderItem={({item})=>(
        <View style={{padding:12,borderBottomWidth:1}}>
          <Text style={{fontWeight:'600'}}>{item.name}</Text>
          <Text>Kapsite: {item.capacity}</Text>
        </View>
      )} />
    </View>
  );
}
