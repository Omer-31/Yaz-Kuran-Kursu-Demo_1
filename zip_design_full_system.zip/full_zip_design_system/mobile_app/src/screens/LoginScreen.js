import React, { useState } from 'react';
import { View, TextInput, Button, Text, StyleSheet, Alert } from 'react-native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function LoginScreen({ navigation }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const API = 'http://10.0.2.2:5000/api/admin'; // emulator için default

  const login = async () => {
    try {
      const res = await axios.post(API + '/login', { username, password });
      const { token } = res.data;
      await AsyncStorage.setItem('token', token);
      global.apiToken = token;
      navigation.replace('AdminTabs');
    } catch (e) {
      Alert.alert('Giriş Hatası', e.response?.data?.message || e.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Yönetici Girişi</Text>
      <TextInput placeholder="Kullanıcı adı" value={username} onChangeText={setUsername} style={styles.input} />
      <TextInput placeholder="Şifre" secureTextEntry value={password} onChangeText={setPassword} style={styles.input} />
      <Button title="Giriş" onPress={login} />
    </View>
  );
}

const styles = StyleSheet.create({ container:{flex:1,justifyContent:'center',padding:20}, input:{borderWidth:1,padding:10,marginBottom:10,borderRadius:6}, title:{fontSize:22, marginBottom:20,textAlign:'center'} });
