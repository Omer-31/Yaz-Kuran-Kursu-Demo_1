import React, { useState, useEffect } from 'react';
import { View, FlatList, Text } from 'react-native';
import axios from 'axios';

export default function Students() {
  const [students, setStudents] = useState([]);
  const API = 'http://10.0.2.2:5000';

  useEffect(()=>fetchStudents(), []);

  const fetchStudents = async () => {
    try {
      const token = global.apiToken;
      const res = await axios.get(API + '/api/students', { headers: { Authorization: 'Bearer ' + token }});
      setStudents(res.data);
    } catch (e) { console.error(e); }
  };

  return (
    <View style={{flex:1}}>
      <FlatList data={students} keyExtractor={i=>''+i.id} renderItem={({item})=>(
        <View style={{padding:12,borderBottomWidth:1}}>
          <Text style={{fontWeight:'600'}}>{item.first_name} {item.last_name}</Text>
          <Text>Durum: {item.registration_status}</Text>
          <Text>Yurt: {item.Dorm ? item.Dorm.name : '—'}</Text>
        </View>
      )} />
    </View>
  );
}
