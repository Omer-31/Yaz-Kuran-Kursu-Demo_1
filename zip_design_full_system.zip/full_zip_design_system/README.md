Full package: backend (Node.js + Express + Sequelize) and mobile (Expo React Native) for the student/dorm system.
- Backend folder: backend (run migrations or schema.sql, then npm install, npm run seed, npm run dev)
- Mobile folder: mobile_app (expo app configured to talk to local backend via 10.0.2.2 for emulator)
- DB schema: backend/schema.sql
- Seed script: backend/seed/adminSeeder.js creates admin/admin123 by default

After downloading, follow README files in each folder to run locally.
