const bcrypt = require('bcrypt');
const { sequelize, Admin } = require('../models');
require('dotenv').config();

async function run() {
  await sequelize.sync();
  const username = process.env.SEED_ADMIN_USER || 'admin';
  const password = process.env.SEED_ADMIN_PASS || 'admin123';
  const hash = await bcrypt.hash(password, 10);
  const exists = await Admin.findOne({ where: { username } });
  if (!exists) {
    await Admin.create({ username, password_hash: hash, name: 'Başlatıcı Yönetici', email: '' });
    console.log('Admin user created ->', username, password);
  } else {
    console.log('Admin already exists');
  }
  process.exit();
}

run().catch(e => { console.error(e); process.exit(1); });
