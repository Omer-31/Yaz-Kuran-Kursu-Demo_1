module.exports = (sequelize, DataTypes) => {
  return sequelize.define('Payment', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    student_id: { type: DataTypes.INTEGER, allowNull: false },
    admin_id: { type: DataTypes.INTEGER },
    amount: { type: DataTypes.DECIMAL(10,2), allowNull: false },
    method: { type: DataTypes.STRING },
    note: { type: DataTypes.TEXT }
  }, {
    tableName: 'payments',
    timestamps: true,
    createdAt: 'paid_at',
    updatedAt: 'created_at'
  });
};
