module.exports = (sequelize, DataTypes) => {
  return sequelize.define('Guardian', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    student_id: { type: DataTypes.INTEGER, allowNull: false },
    name: { type: DataTypes.STRING, allowNull: false },
    phone: { type: DataTypes.STRING },
    email: { type: DataTypes.STRING },
    relation: { type: DataTypes.STRING },
    is_primary: { type: DataTypes.BOOLEAN, defaultValue: false }
  }, {
    tableName: 'guardians',
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at'
  });
};
