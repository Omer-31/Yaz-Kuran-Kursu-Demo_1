module.exports = (sequelize, DataTypes) => {
  return sequelize.define('Registration', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    student_id: { type: DataTypes.INTEGER },
    form_data: { type: DataTypes.JSON },
    status: { type: DataTypes.ENUM('beklemede','tamamlandi'), defaultValue: 'beklemede' }
  }, {
    tableName: 'registrations',
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at'
  });
};
