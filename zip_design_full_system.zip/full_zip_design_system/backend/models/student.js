module.exports = (sequelize, DataTypes) => {
  return sequelize.define('Student', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    first_name: { type: DataTypes.STRING, allowNull: false },
    last_name: { type: DataTypes.STRING, allowNull: false },
    birth_date: { type: DataTypes.DATEONLY },
    national_id: { type: DataTypes.STRING },
    dorm_id: { type: DataTypes.INTEGER },
    registration_status: { type: DataTypes.ENUM('onayli','onayda','yedek'), defaultValue: 'onayda' }
  }, {
    tableName: 'students',
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at'
  });
};
