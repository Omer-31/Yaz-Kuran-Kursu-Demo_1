const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize(process.env.DB_NAME || 'zipdb', process.env.DB_USER || 'root', process.env.DB_PASS || '', {
  host: process.env.DB_HOST || '127.0.0.1',
  port: process.env.DB_PORT || 3306,
  dialect: 'mysql',
  logging: false
});

const Admin = require('./admin')(sequelize, DataTypes);
const Dorm = require('./dorm')(sequelize, DataTypes);
const Student = require('./student')(sequelize, DataTypes);
const Guardian = require('./guardian')(sequelize, DataTypes);
const Payment = require('./payment')(sequelize, DataTypes);
const Registration = require('./registration')(sequelize, DataTypes);

// associations
Dorm.hasMany(Student, { foreignKey: 'dorm_id' });
Student.belongsTo(Dorm, { foreignKey: 'dorm_id' });
Student.hasMany(Guardian, { foreignKey: 'student_id' });
Guardian.belongsTo(Student, { foreignKey: 'student_id' });
Student.hasMany(Payment, { foreignKey: 'student_id' });
Payment.belongsTo(Student, { foreignKey: 'student_id' });

module.exports = { sequelize, Admin, Dorm, Student, Guardian, Payment, Registration };
