module.exports = (sequelize, DataTypes) => {
  return sequelize.define('Dorm', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING, allowNull: false },
    capacity: { type: DataTypes.INTEGER, defaultValue: 0 },
    location: { type: DataTypes.STRING }
  }, {
    tableName: 'dorms',
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at'
  });
};
