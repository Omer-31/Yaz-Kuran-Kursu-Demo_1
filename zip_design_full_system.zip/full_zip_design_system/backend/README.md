# Backend (Node.js + Express + Sequelize)

## Kurulum (lokalde MySQL ile çalıştırmak için)

1. MySQL kur (örneğin XAMPP veya native MySQL). Bir veritabanı `zipdb` oluştur veya `schema.sql`'i çalıştır.
2. Proje dizinine gelin:
   ```bash
   cd backend
   npm install
   cp .env.sample .env
   # .env içindeki DB bilgilerini doldurun (DB_USER, DB_PASS...)
   ```
3. Veritabanı tablolarını oluşturmak için:
   ```bash
   # ya schema.sql'i mysql ile çalıştır
   mysql -u root -p < schema.sql
   # veya otomatik sync için (Sequelize) aşağıyı çalıştırın:
   npm run seed
   ```
4. Sunucuyu başlatın:
   ```bash
   npm run dev
   ```
5. Varsayılan seed admin: `.env` ile SEED_ADMIN_USER ve SEED_ADMIN_PASS ayarlanmazsa `admin` / `admin123` olacak.

API base URL: http://localhost:5000/api
