const express = require('express');
const router = express.Router();
const { Registration } = require('../models');

router.post('/', async (req, res) => {
  const { form_data } = req.body;
  const r = await Registration.create({ form_data });
  res.json({ message: 'Registration saved', id: r.id });
});

module.exports = router;
