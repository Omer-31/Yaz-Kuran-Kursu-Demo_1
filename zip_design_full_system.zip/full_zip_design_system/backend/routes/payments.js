const express = require('express');
const router = express.Router();
const { Payment, Student } = require('../models');
const authMiddleware = require('../utils/authMiddleware');

router.post('/', authMiddleware, async (req, res) => {
  const adminId = req.user.id;
  const { student_id, amount, method, note } = req.body;
  if (!student_id || !amount) return res.status(400).json({ message: 'student_id ve amount gerekli' });
  const student = await Student.findByPk(student_id);
  if (!student) return res.status(404).json({ message: 'Öğrenci bulunamadı' });
  const p = await Payment.create({ student_id, amount, method, note, admin_id: adminId });
  res.json(p);
});

router.get('/', authMiddleware, async (req, res) => {
  const student_id = req.query.student_id;
  const where = student_id ? { student_id } : {};
  const payments = await Payment.findAll({ where });
  res.json(payments);
});

module.exports = router;
