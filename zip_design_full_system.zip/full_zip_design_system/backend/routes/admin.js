const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { Admin, Student, Payment, Dorm } = require('../models');
const authMiddleware = require('../utils/authMiddleware');
const JWT_SECRET = process.env.JWT_SECRET || 'change_this_secret';

router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const admin = await Admin.findOne({ where: { username } });
  if (!admin) return res.status(401).json({ message: 'Kullanıcı bulunamadı' });
  const ok = await bcrypt.compare(password, admin.password_hash);
  if (!ok) return res.status(401).json({ message: 'Hatalı şifre' });
  const token = jwt.sign({ id: admin.id, username: admin.username }, JWT_SECRET, { expiresIn: '8h' });
  res.json({ token, admin: { id: admin.id, username: admin.username, name: admin.name } });
});

router.get('/dashboard', authMiddleware, async (req, res) => {
  const totalStudents = await Student.count();
  const paymentsSum = await Payment.sum('amount') || 0;
  const dorms = await Dorm.findAll();
  res.json({ totalStudents, paymentsSum, dorms });
});

module.exports = router;
