const express = require('express');
const router = express.Router();
const { Student, Dorm } = require('../models');
const authMiddleware = require('../utils/authMiddleware');

router.get('/', authMiddleware, async (req, res) => {
  const status = req.query.status;
  const where = status ? { registration_status: status } : {};
  const students = await Student.findAll({ where, include: [{ model: Dorm }] });
  res.json(students);
});

router.get('/:id', authMiddleware, async (req, res) => {
  const s = await Student.findByPk(req.params.id, { include: [{ model: Dorm }] });
  if (!s) return res.status(404).json({ message: 'Not found' });
  res.json(s);
});

router.post('/', authMiddleware, async (req, res) => {
  const data = req.body;
  const s = await Student.create(data);
  res.json(s);
});

router.put('/:id', authMiddleware, async (req, res) => {
  const s = await Student.findByPk(req.params.id);
  if (!s) return res.status(404).json({ message: 'Not found' });
  await s.update(req.body);
  res.json(s);
});

module.exports = router;
