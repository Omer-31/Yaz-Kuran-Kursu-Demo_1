const express = require('express');
const router = express.Router();
const { Dorm } = require('../models');
const authMiddleware = require('../utils/authMiddleware');

router.get('/', authMiddleware, async (req, res) => {
  const d = await Dorm.findAll();
  res.json(d);
});

router.post('/', authMiddleware, async (req, res) => {
  const d = await Dorm.create(req.body);
  res.json(d);
});

module.exports = router;
