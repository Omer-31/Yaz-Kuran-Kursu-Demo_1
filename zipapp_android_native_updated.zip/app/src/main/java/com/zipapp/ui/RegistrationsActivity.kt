package com.zipapp.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.zipapp.R

class RegistrationsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(android.R.layout.simple_list_item_1)
        title = "Registrations"
    }
}
