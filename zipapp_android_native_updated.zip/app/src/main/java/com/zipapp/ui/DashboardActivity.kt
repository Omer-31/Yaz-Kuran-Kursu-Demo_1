package com.zipapp.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.zipapp.R

class DashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        val tv = findViewById<TextView>(R.id.tvWelcome)
        val btnStudents = findViewById<Button>(R.id.btnStudents)
        val btnDorms = findViewById<Button>(R.id.btnDorms)
        val btnRegs = findViewById<Button>(R.id.btnRegistrations)

        btnStudents.setOnClickListener {
            startActivity(Intent(this, StudentsActivity::class.java))
        }
        btnDorms.setOnClickListener {
            startActivity(Intent(this, DormsActivity::class.java))
        }
        btnRegs.setOnClickListener {
            startActivity(Intent(this, RegistrationsActivity::class.java))
        }
    }
}
