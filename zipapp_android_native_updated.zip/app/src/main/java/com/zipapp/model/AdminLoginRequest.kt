package com.zipapp.model

data class AdminLoginRequest(
    val username: String,
    val password: String
)
