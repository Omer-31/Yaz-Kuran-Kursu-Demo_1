package com.zipapp.model

data class AdminLoginResponse(
    val success: Boolean,
    val token: String?,
    val message: String?
)
