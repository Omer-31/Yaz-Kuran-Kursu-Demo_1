package com.zipapp.model

data class Student(
    val id: Int? = null,
    val name: String,
    val email: String?
)
