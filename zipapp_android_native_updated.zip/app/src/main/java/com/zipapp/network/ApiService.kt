package com.zipapp.network

import com.zipapp.model.AdminLoginRequest
import com.zipapp.model.AdminLoginResponse
import com.zipapp.model.Student
import retrofit2.Response
import retrofit2.http.*

interface ApiService {
    @POST("/admin/login")
    suspend fun adminLogin(@Body body: AdminLoginRequest): Response<AdminLoginResponse>

    @GET("/admin/dashboard")
    suspend fun getDashboard(): Response<Map<String, Any>>

    @GET("/students")
    suspend fun listStudents(): Response<List<Student>>

    @POST("/students")
    suspend fun createStudent(@Body student: Student): Response<Student>

    @GET("/students/{id}")
    suspend fun getStudent(@Path("id") id: Int): Response<Student>

    @PUT("/students/{id}")
    suspend fun updateStudent(@Path("id") id: Int, @Body student: Student): Response<Student>

    @GET("/dorms")
    suspend fun listDorms(): Response<List<Map<String,Any>>>

    @POST("/registrations")
    suspend fun register(@Body body: Map<String,Any>): Response<Map<String,Any>>

    @GET("/payments")
    suspend fun listPayments(): Response<List<Map<String,Any>>>

    @POST("/payments")
    suspend fun createPayment(@Body body: Map<String,Any>): Response<Map<String,Any>>
}
